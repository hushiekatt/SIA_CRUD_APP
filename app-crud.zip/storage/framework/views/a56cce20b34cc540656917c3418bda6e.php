<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('DESSERTS')); ?>

            </h2>
            <a href="<?php echo e(route('prod.index')); ?>" class="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600">Orders</a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <?php echo e(__("Hello! Welcome to your sweet tooth!")); ?>

                    
                </div>
            </div>

            <!-- Container for Products -->
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-6">
                <!-- Product 1 -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <img src="<?php echo e(asset('images/product1.png')); ?>" alt="Product 1" class="w-full h-48 object-cover">
                    <div class="p-6 text-gray-900">
                        <h3 class="font-semibold text-lg">Product 1</h3>
                        <p class="text-sm text-gray-500">$10.00</p>
                        <p class="mt-2">Description of Product 1</p>
                    </div>
                </div>

                <!-- Product 2 -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <img src="<?php echo e(asset('images/product2.png')); ?>" alt="Product 2" class="w-full h-48 object-cover">
                    <div class="p-6 text-gray-900">
                        <h3 class="font-semibold text-lg">Product 2</h3>
                        <p class="text-sm text-gray-500">$15.00</p>
                        <p class="mt-2">Description of Product 2</p>
                    </div>
                </div>

                <!-- Product 3 -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <img src="<?php echo e(asset('images/product3.png')); ?>" alt="Product 3" class="w-full h-48 object-cover">
                    <div class="p-6 text-gray-900">
                        <h3 class="font-semibold text-lg">Product 3</h3>
                        <p class="text-sm text-gray-500">$20.00</p>
                        <p class="mt-2">Description of Product 3</p>
                    </div>
                </div>

                <!-- Product 4 -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <img src="<?php echo e(asset('images/product4.png')); ?>" alt="Product 4" class="w-full h-48 object-cover">
                    <div class="p-6 text-gray-900">
                        <h3 class="font-semibold text-lg">Product 4</h3>
                        <p class="text-sm text-gray-500">$25.00</p>
                        <p class="mt-2">Description of Product 4</p>
                    </div>
                </div>

                <!-- Repeat for other products -->
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\For APP\app-crud\resources\views/dashboard.blade.php ENDPATH**/ ?>