<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="shortcut icon" type="x-icon" href="images/ice-cream-logo.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order List</title>
    <link rel="stylesheet" href="/css/stylesheet.css">
</head>
<body>
    <div class="container">
        <h1 class="heading">Your Order</h1>

        <div class="success-message">
            <?php if(session()->has('success')): ?>
                <div>
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
        </div>

        <div class="button-group">
            <a href="<?php echo e(route('product.create')); ?>" class="btn">Create a Product</a>
            <a href="<?php echo e(url('/dashboard')); ?>" class="btn">Go to Dashboard</a> <!-- Dashboard button -->
        </div>

        <div class="order-table">
            <table>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Qty</th>
                    <th>Price</th>
                    <th>Description</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($product->id); ?></td>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->qty); ?></td>
                        <td><?php echo e($product->price); ?></td>
                        <td><?php echo e($product->description); ?></td>
                        <td>
                            <a href="<?php echo e(route('prod.edit', ['product' => $product])); ?>" class="action-link">Edit</a>
                        </td>
                        <td>
                            <form method="post" action="<?php echo e(route('product.destroy', ['product' => $product])); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <input type="submit" value="Delete" class="action-button" />
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\For APP\app-crud\resources\views/prod/index.blade.php ENDPATH**/ ?>