<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
</head>
<body>
    <h1>Edit Product</h1>
    <form method="post" action="<?php echo e(route('product.update', ['product' => $product])); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <div>
            <label for="name">Name</label>
            <input type="text" name="name" placeholder="Name" value="<?php echo e($product->name); ?>" />
        </div>
        <div>
            <label for="qty">Quantity</label>
            <input type="text" name="qty" placeholder="Quantity" value="<?php echo e($product->qty); ?>" />
        </div>
        <div>
            <label for="price">Price</label>
            <input type="text" name="price" placeholder="Price" value="<?php echo e($product->price); ?>" />
        </div>
        <div>
            <label for="description">Description</label>
            <input type="text" name="description" placeholder="Description" value="<?php echo e($product->descreption); ?>" />
        </div>
        <div>
            <input type="submit" value="Update" />
        </div>
    </form>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\For APP\app-crud\resources\views/prod/edit.blade.php ENDPATH**/ ?>